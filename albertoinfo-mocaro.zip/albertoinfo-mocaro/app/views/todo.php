<h1> Pendiente de implementar </h1>
<button onclick="history.back()"> Volver </button>